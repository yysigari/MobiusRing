% DD.m, drift space
function out=DD(L)
out=eye(5);
out(1,2)=L;
out(3,4)=L;
