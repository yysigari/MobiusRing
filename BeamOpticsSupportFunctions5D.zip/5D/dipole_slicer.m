% beamline_slicer.m
function out=dipole_slicer(beamline,nslice)
nlines=size(beamline,1); 
out=beamline;
for line=1:nlines  
  if beamline(line,1)==4   % dipole found
    out(line,2)=out(line,2)*nslice;
    out(line,3)=out(line,3)/nslice;
    out(line,4)=out(line,4)/nslice;
  end
end
