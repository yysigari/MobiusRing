% periodic_beammatrix.m, return the periodic beam-matrix 
function sigma=periodic_beammatrix(Rend,epsx,epsy,sigp)
if nargin==3, sigp=0; end
[Qx,alphax,betax,gammax]=R2beta(Rend(1:2,1:2));
[Qy,alphay,betay,gammay]=R2beta(Rend(3:4,3:4));
sigma=zeros(5,5);
sigma(1:2,1:2)=epsx*[betax,-alphax;-alphax,gammax];
sigma(3:4,3:4)=epsy*[betay,-alphay;-alphay,gammay];
sigma(5,5)=sigp^2;