% calcmat.m, calculate the transfer-matrices
function [Racc,spos,nmat,nlines,ibl]=calcmat(beamline)
ndim=size(DD(1),1);  
nlines=size(beamline,1);      % number of lines in beamline
nmat=sum(beamline(:,2))+1;    % sum over repeat-count in column 2
Racc=zeros(ndim,ndim,nmat);   % matrices from start to element-end
Racc(:,:,1)=eye(ndim);        % initialize first with unit matrix
ibl=zeros(nmat,1);            % position in beamline file
spos=zeros(nmat,1);           % longitudinal position
ic=1;                         % element counter
ibl(1)=1;
for line=1:nlines             % loop over input elements  
  for seg=1:beamline(line,2)  % loop over repeat-count 
     ic=ic+1;                 % next element     
     Rcurr=eye(ndim);         % matrix in next element
     switch beamline(line,1)  
       case 1   % drift
         Rcurr=DD(beamline(line,3));
       case 2   % thin quadrupole
         Rcurr=Q(beamline(line,4)); 
       case 4   % sector dipole
         phi=beamline(line,4)*pi/180;  % convert to radians
         rho=beamline(line,3)/phi;
         Rcurr=SB(beamline(line,3),rho);
       case 5   % thick quadrupole
         Rcurr=QQ(beamline(line,3),beamline(line,4));           
       case 20  % coordinate roll
         Rcurr=ROLL(beamline(line,4)); 
       case 60  % skew qquadrupole
         Rcurr=SQ(beamline(line,4));
       case 201 % phase advance in X    
         phasex=beamline(line,4)*pi/180;
         cx=cos(phasex); sx=sin(phasex);
         Rcurr(1,1)=cx; Rcurr(1,2)=sx; Rcurr(2,1)=-sx; Rcurr(2,2)=cx;
       case 202 % phase advance in Y
          phasey=beamline(line,4)*pi/180;
          cy=cos(phasey); sy=sin(phasey);
          Rcurr(3,3)=cy; Rcurr(3,4)=sy; Rcurr(4,3)=-sy; Rcurr(4,4)=cy;
       otherwise
         current_line=line;
         %disp('unsupported code')
     end		  
     Racc(:,:,ic)=Rcurr*Racc(:,:,ic-1);    % concatenate 
     spos(ic)=spos(ic-1)+beamline(line,3); % position of element  
     ibl(ic)=line;             % where is description of segment
  end
end