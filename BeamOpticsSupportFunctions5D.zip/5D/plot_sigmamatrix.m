% plot_sigmammatrix.m
function [sigx,sigy]=plot_sigmamatrix(beamline,sigma0)
[Racc,spos,nmat,nlines,ibl]=calcmat(beamline);
inroll=0; Rs=eye(5);
sigx=zeros(1,nmat); sigy=sigx; 
for k=1:nmat
  if beamline(ibl(k),1)==20    % coordinate rotation found
    if inroll==0
      inroll=1; Rs=ROLL(-beamline(ibl(k),4));
    else
      inroll=0; Rs=eye(5);
    end 
  end
  RR=Rs*Racc(:,:,k); sig=RR*sigma0*RR';
  sigx(k)=sqrt(sig(1,1)); sigy(k)=sqrt(sig(3,3));
end
plot(spos,sigx*1e3,'k',spos,sigy*1e3,'r-.','LineWidth',2)
xlim([min(spos),max(spos)])
xlabel('s [m]'); ylabel('\sigma_x, \sigma_y [mm]')
legend('\sigma_x','\sigma_y')
title('Beam sizes')
set(gca,'FontSize',16)
set(gcf,'Position',[2800,-200,1400,500])
end