% periodic_dispersion.m
function D0=periodic_dispersion(Rend)
D=(eye(4)-Rend(1:4,1:4))\Rend(1:4,5);
D0=[D;1];
end