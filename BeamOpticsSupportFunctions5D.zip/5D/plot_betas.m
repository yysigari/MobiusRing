% plot_betas.m, V. Ziemann
function plot_betas(beamline,sigma0)
[Racc,spos]=calcmat(beamline);
betax=zeros(1,length(spos)); betay=betax;
for k=1:length(spos)
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   betax(k)=sigma(1,1); betay(k)=sigma(3,3);
end
% plot(spos,betax,'k',spos,betay,'k-.'); 
plot(spos,betax,'k',spos,betay,'r-.','LineWidth',2); 
xlabel(' s[m]'); ylabel('\beta_x,\beta_y [m]')
legend('\beta_x','\beta_y')
axis([0, max(spos), 0, 1.05*max([betax,betay])])
end
