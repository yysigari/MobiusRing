% radiation_integrals.m
function [I1,I2,I3,I4,I5]=radiation_integrals(beamline,flipped)
if nargin==1, flipped=0; end
[Racc,spos,nmat,nlines]=calcmat(beamline);
Rturn=Racc(:,:,end);
[O,A,T,p]=sagrub(Rturn,flipped);
D0=periodic_dispersion(Rturn);
rho=zeros(nmat,1);
ic=1;              % copied from calcmat
for line=1:nlines  % needed because of segmentation      
  for seg=1:beamline(line,2)  
     ic=ic+1;                        
     switch beamline(line,1)  
       case 4      % sector dipole
         phi=beamline(line,4)*pi/180;  % convert to radians
         rho(ic)=beamline(line,3)/phi;
     end
  end
end

I1=0; I2=0; I3=0; I4a=0; I4b=0; I5a=0; I5b=0;  % initialize to zero
for k=2:nmat-1   % loop over lattice
  if abs(rho(k)) > 1e-9
    fudge=1;
    if abs(rho(k-1)) < 1e-9, fudge=0.5; end   % end segments at start
    if abs(rho(k+1)) < 1e-9, fudge=0.5; end   % and exit of element
    ds=spos(k)-spos(k-1);                     % length of segment
    R=Racc(:,:,k)*Rturn*inv(Racc(:,:,k));     % move FTM to point k
    [O,A,T,p]=sagrub(R,flipped); Sinv=A*T; 
    try
      S=inv(Sinv);
    catch
      disp('Warning in radiation_integrals: failed inverse!')
      S=0*Sinv;
    end
    Dxy=Racc(:,:,k)*D0;  D=Sinv*Dxy(1:4);  
    Ha=D(1)^2+D(2)^2; Hb=D(3)^2+D(4)^2;
    %HH=[D',Ha,Hb]
    I1=I1+ds*fudge*Dxy(1)/rho(k);                        % [m]
    I2=I2+ds*fudge/rho(k)^2;                             % [1/m]
    I3=I3+ds*fudge/abs(rho(k))^3;                        % [1/m^2]
    I4a=I4a+ds*fudge*(S(1,1)*D(1)+S(1,2)*D(2))/rho(k)^3; % [1/m]
    I4b=I4b+ds*fudge*(S(1,3)*D(3)+S(1,4)*D(4))/rho(k)^3; % [1/m]
    I5a=I5a+ds*fudge*Ha/rho(k)^3;                        % [1/m]
    I5b=I5b+ds*fudge*Hb/rho(k)^3;                        % [1/m]    
  end
end
I4=[I4a,I4b];
I5=[I5a,I5b];
end