% plot_beta_unrolled.m
function [beta1,beta2,disp,Qtune]=plot_betas_unrolled(beamline,flipped,show)
if nargin==1, flipped=0; end              % default, use SR eq.8+9
if nargin==2, show=1; end
unroll=1; if flipped==-1, unroll=0; end  % flipped=-1 turns of unrolling
[Racc,spos,nmat,nlines,ibl]=calcmat(beamline);
Rturn=Racc(:,:,end);
[O,A,T,p]=sagrub(Rturn,flipped);
if p(4) < p(1), flipped=~flipped; [O,A,T,p]=sagrub(Rturn,flipped); end  % ensure [Qy]>[Qx]
S1=A*T; S1inv=inv(S1);
D0=periodic_dispersion(Rturn);
inroll=0; Rs=eye(5);   % prepare for the unrolling of coordinate rotations
beta1=zeros(1,nmat); beta2=beta1; disp=zeros(nmat,2);
Qtune=zeros(nmat,2); dQ1l=0; dQ2l=0;  % needed for phase advances
for k=1:nmat
  if unroll==1 && beamline(ibl(k),1)==20  % coordinate rotation found
    if inroll==0  % rotation found and NOT in rolled region
      inroll=1; Rs=ROLL(-beamline(ibl(k),4));  % Rs = unroll matrix
    else          % found the un-rotation after the element
      inroll=0; Rs=eye(5);  % no unrolling needed any more
    end 
  end
  R=Rs*Racc(:,:,k)*Rturn*inv(Rs*Racc(:,:,k));  % move FTM to point k 
  [O,A,T,p]=sagrub(R,flipped); beta1(k)=p(3); beta2(k)=p(6); % betas
  D=Rs*Racc(:,:,k)*D0; disp(k,1)=D(1); disp(k,2)=D(3);    % dispersions
  if k>1 %.................phase advances from second element onwards
    R12=Rs*Racc(:,:,k);                % unrolled!
    S2=A*T;
    OO=S2*R12(1:4,1:4)*S1inv;          % two rotations on diagonal, 211224
    if abs(det(OO(1:2,1:2))) < 1e-12   % flipped mode
      [O,A,T,p]=sagrub(R,~flipped);    % use the other mode
      S2=A*T;
      OO=S2*R12(1:4,1:4)*S1inv; 
    end
    mu1=acos(0.5*(OO(1,1)+OO(2,2)));    % phase a
    if OO(1,2)<-1e-12, mu1=2*pi-mu1; end; dQ1=mu1/(2*pi); 
    Qtune(k,1)=Qtune(k-1,1)+dQ1-dQ1l;
    if dQ1l > dQ1+0.25, Qtune(k,1)=Qtune(k,1)+1; end
    mu2=acos(0.5*(OO(3,3)+OO(4,4)));    % phase b
    if OO(3,4)<-1e-12, mu2=2*pi-mu2; end; dQ2=mu2/(2*pi);
    Qtune(k,2)=Qtune(k-1,2)+dQ2-dQ2l;
    if dQ2l > dQ2+0.25, Qtune(k,2)=Qtune(k,2)+1; end
%     if k>39 & k<45
%       sagrub_dump=[k,OO(1,2),mu1,dQ1,dQ1l,OO(3,4),mu2,dQ2,dQ2l]   
%     end
    dQ1l=dQ1; dQ2l=dQ2;
  end 
end
if show==0, return; end
%......................................  only plotting below
subplot(2,1,1);   
plot(spos,real(beta1),'k',spos,real(beta2),'r-.','LineWidth',2); 
xlim([min(spos),max(spos)])
xlabel('s [m]'); ylabel('\beta_a, \beta_b'); legend('\beta_a','\beta_b')
title(['Beta functions: Q_a= ',num2str(Qtune(end,1),'%8.3f'),'  Q_b= ',num2str(Qtune(end,2),'%8.3f')])
drawmag(beamline,1,2)
set(gca,'FontSize',16)

subplot(2,1,2);
plot(spos,real(disp(:,1)),'k',spos,real(disp(:,2)),'r-.','LineWidth',2);
xlim([min(spos),max(spos)])
xlabel('s [m]'); ylabel('D_a, D_b'); legend('D_a','D_b')
title('Dispersions')
set(gca,'FontSize',16)
set(gcf,'Position',[270,-100,1400,900])

figure
plot(spos,real(Qtune(:,1)),'k',spos,real(Qtune(:,2)),'r-.','LineWidth',2)
xlabel('s [m]'); ylabel('\mu_a/2\pi, \mu_b/2\pi')
legend('\mu_a/2\pi','\mu_b/2\pi','Location','NorthWest');
xlim([min(spos),max(spos)]);
set(gca,'FontSize',16)
set(gcf,'Position',[270,-100,1400,900])
end
