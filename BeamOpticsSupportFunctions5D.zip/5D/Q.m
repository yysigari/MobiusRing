% Q.m thin quadrupole
function out=Q(F)
out=eye(5);
if abs(F)<1e-8, return; end
out(2,1)=-1/F;
out(4,3)=1/F;

