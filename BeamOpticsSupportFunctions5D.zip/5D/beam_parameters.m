% beam_parameters.m for electrons
% energy E0 [MeV]
% circumference C [m]
function [alpha,sigp,tau,eps]=beam_parameters(E0,C,I1,I2,I3,I4,I5) 
gamma0=E0/0.511;   
T0=C/3e8;
alpha=I1/C;                            % eq. 3.102
Cq=3.83e-13;
sigp2=Cq*gamma0^2*I3/(2*I2+sum(I4));   % eq. 10.10
sigp=sqrt(sigp2);
eps=Cq*gamma0^2*I5./(I2-I4);           % eq. 10.19
Cgamma=8.846e-5;                       % m/GeV^3
Cgamma=Cgamma/1e9;                     % m/MeV^3
U0=Cgamma*E0^4*I2/(2*pi);              % MeV
JJ=1-I4/I2;                            % partition numbers Ja, Jb
tau=(2*E0*T0/U0)./[JJ,4-sum(JJ)];


