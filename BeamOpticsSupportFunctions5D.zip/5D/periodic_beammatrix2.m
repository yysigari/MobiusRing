% periodic_beammatrix2.m, returns the periodic beam-matrix 
% in coupled lattices
function sigma=periodic_beammatrix2(Rend,epsx,epsy,sigp,flipped)
if nargin<5, flipped=0; end
[O,A,T,para]=sagrub(Rend(1:4,1:4),flipped);
sigma=zeros(5);
iAT=inv(A*T);
sigma(1:4,1:4)=iAT*diag([epsx,epsx,epsy,epsy])*iAT';   % more stable
if sigp > 0
  D0=periodic_dispersion(Rend);
  sigma=sigma+D0*D0'*sigp^2;  % add momentum spread
end
end